﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;

namespace ProjetoPOO
{
    public enum TipoEvento
    {
        Login,
        Logout,
        VotoRegistrado,
        EleicaoCriada,
        CandidatoAdicionado,
        TentativaVotoInvalida,
        AlteracaoSenha
    }

    public class EventoAuditoria
    {
        public DateTime DataHora { get; set; }
        public TipoEvento Tipo { get; set; }
        public string UsuarioId { get; set; }
        public string Descricao { get; set; }
        public string Detalhes { get; set; }

        public override string ToString()
        {
            return $"[{DataHora:dd/MM/yyyy HH:mm:ss}] {Tipo} - {UsuarioId}: {Descricao}";
        }
    }

    public class Auditoria
    {
        private List<EventoAuditoria> eventos;
        private readonly string caminhoArquivo = "auditoria_log.txt";

        public Auditoria()
        {
            eventos = new List<EventoAuditoria>();
        }

        public void RegistrarEvento(TipoEvento tipo, string usuarioId, string descricao, string detalhes = "")
        {
            var evento = new EventoAuditoria
            {
                DataHora = DateTime.Now,
                Tipo = tipo,
                UsuarioId = usuarioId ?? "Sistema",
                Descricao = descricao,
                Detalhes = detalhes
            };

            eventos.Add(evento);

            // Opcional: Gravar em arquivo
            GravarEmArquivo(evento);
        }

        private void GravarEmArquivo(EventoAuditoria evento)
        {
            try
            {
                using (StreamWriter sw = File.AppendText(caminhoArquivo))
                {
                    sw.WriteLine(evento.ToString());
                    if (!string.IsNullOrEmpty(evento.Detalhes))
                    {
                        sw.WriteLine($"  Detalhes: {evento.Detalhes}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"⚠️ Erro ao gravar log: {ex.Message}");
            }
        }

        public void ExibirHistorico(int ultimosN = 20)
        {
            Console.WriteLine("\n==========================================");
            Console.WriteLine("         HISTÓRICO DE AUDITORIA");
            Console.WriteLine("==========================================");

            if (eventos.Count == 0)
            {
                Console.WriteLine("Nenhum evento registrado.");
                return;
            }

            var eventosRecentes = eventos.OrderByDescending(e => e.DataHora).Take(ultimosN);

            foreach (var evento in eventosRecentes)
            {
                Console.WriteLine(evento);
                if (!string.IsNullOrEmpty(evento.Detalhes))
                {
                    Console.WriteLine($"  → {evento.Detalhes}");
                }
            }

            Console.WriteLine($"\nTotal de eventos: {eventos.Count}");
        }

        public void ExibirEventosPorUsuario(string usuarioId)
        {
            Console.WriteLine($"\n--- Eventos do usuário: {usuarioId} ---");

            var eventosUsuario = eventos.Where(e => e.UsuarioId == usuarioId).ToList();

            if (eventosUsuario.Count == 0)
            {
                Console.WriteLine("Nenhum evento registrado para este usuário.");
                return;
            }

            foreach (var evento in eventosUsuario.OrderByDescending(e => e.DataHora))
            {
                Console.WriteLine(evento);
            }

            Console.WriteLine($"\nTotal: {eventosUsuario.Count} eventos");
        }

        public void ExibirEventosPorTipo(TipoEvento tipo)
        {
            Console.WriteLine($"\n--- Eventos do tipo: {tipo} ---");

            var eventosTipo = eventos.Where(e => e.Tipo == tipo).ToList();

            if (eventosTipo.Count == 0)
            {
                Console.WriteLine("Nenhum evento deste tipo registrado.");
                return;
            }

            foreach (var evento in eventosTipo.OrderByDescending(e => e.DataHora))
            {
                Console.WriteLine(evento);
            }

            Console.WriteLine($"\nTotal: {eventosTipo.Count} eventos");
        }

        public void ExibirEstatisticas()
        {
            Console.WriteLine("\n==========================================");
            Console.WriteLine("      ESTATÍSTICAS DE AUDITORIA");
            Console.WriteLine("==========================================");

            if (eventos.Count == 0)
            {
                Console.WriteLine("Nenhum evento registrado.");
                return;
            }

            var estatisticasPorTipo = eventos
                .GroupBy(e => e.Tipo)
                .Select(g => new { Tipo = g.Key, Quantidade = g.Count() })
                .OrderByDescending(x => x.Quantidade);

            Console.WriteLine("\nEventos por tipo:");
            foreach (var stat in estatisticasPorTipo)
            {
                Console.WriteLine($"  {stat.Tipo}: {stat.Quantidade}");
            }

            var usuariosAtivos = eventos
                .Where(e => !string.IsNullOrEmpty(e.UsuarioId))
                .GroupBy(e => e.UsuarioId)
                .Select(g => new { Usuario = g.Key, Atividades = g.Count() })
                .OrderByDescending(x => x.Atividades)
                .Take(5);

            Console.WriteLine("\nTop 5 usuários mais ativos:");
            foreach (var user in usuariosAtivos)
            {
                Console.WriteLine($"  {user.Usuario}: {user.Atividades} atividades");
            }

            var primeiroEvento = eventos.OrderBy(e => e.DataHora).FirstOrDefault();
            var ultimoEvento = eventos.OrderByDescending(e => e.DataHora).FirstOrDefault();

            Console.WriteLine($"\nPrimeiro evento: {primeiroEvento?.DataHora:dd/MM/yyyy HH:mm}");
            Console.WriteLine($"Último evento: {ultimoEvento?.DataHora:dd/MM/yyyy HH:mm}");
            Console.WriteLine($"Total de eventos: {eventos.Count}");
        }

        public List<EventoAuditoria> PesquisarEventos(DateTime dataInicio, DateTime dataFim)
        {
            return eventos
                .Where(e => e.DataHora >= dataInicio && e.DataHora <= dataFim)
                .OrderByDescending(e => e.DataHora)
                .ToList();
        }

        public void LimparHistorico()
        {
            Console.Write("Tem certeza que deseja limpar todo o histórico? (S/N): ");
            var confirmacao = Console.ReadLine();

            if (confirmacao?.ToUpper() == "S")
            {
                eventos.Clear();
                Console.WriteLine("✓ Histórico limpo com sucesso!");
            }
            else
            {
                Console.WriteLine("Operação cancelada.");
            }
        }
    }
}