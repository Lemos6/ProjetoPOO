﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ProjetoPOO
{
    public class Autenticacao
    {
        private Dictionary<string, string> credenciais; // Id -> Senha (hash simulado)
        private HashSet<string> sessoesAtivas;
        private Dictionary<string, DateTime> tentativasLogin; // Id -> Última tentativa
        private Dictionary<string, int> falhasLogin; // Id -> Número de falhas

        private const int MaxTentativas = 3;
        private const int MinutosBloqueio = 5;

        public Autenticacao()
        {
            credenciais = new Dictionary<string, string>();
            sessoesAtivas = new HashSet<string>();
            tentativasLogin = new Dictionary<string, DateTime>();
            falhasLogin = new Dictionary<string, int>();

            InicializarCredenciaisExemplo();
        }

        private void InicializarCredenciaisExemplo()
        {
            // Senhas simples para exemplo (em produção, usar hash real)
            credenciais["E001"] = "1234";
            credenciais["E002"] = "1234";
            credenciais["E003"] = "1234";
            credenciais["E004"] = "1234";
            credenciais["E005"] = "1234";
        }

        public bool RegistrarCredencial(string eleitorId, string senha)
        {
            if (string.IsNullOrWhiteSpace(eleitorId) || string.IsNullOrWhiteSpace(senha))
            {
                Console.WriteLine("❌ ID e senha não podem estar vazios!");
                return false;
            }

            if (senha.Length < 4)
            {
                Console.WriteLine("❌ Senha deve ter no mínimo 4 caracteres!");
                return false;
            }

            if (credenciais.ContainsKey(eleitorId))
            {
                Console.WriteLine("❌ Este eleitor já tem credenciais registradas!");
                return false;
            }

            credenciais[eleitorId] = senha; // Em produção: HashSenha(senha)
            Console.WriteLine("✓ Credenciais registradas com sucesso!");
            return true;
        }

        public bool Autenticar(string eleitorId, string senha)
        {
            if (string.IsNullOrWhiteSpace(eleitorId) || string.IsNullOrWhiteSpace(senha))
            {
                Console.WriteLine("❌ ID e senha não podem estar vazios!");
                return false;
            }

            // Verificar se está bloqueado
            if (EstaBloqueado(eleitorId))
            {
                var tempoRestante = ObterTempoRestanteBloqueio(eleitorId);
                Console.WriteLine($"❌ Conta bloqueada! Tente novamente em {tempoRestante.Minutes}m {tempoRestante.Seconds}s");
                return false;
            }

            // Verificar credenciais
            if (!credenciais.ContainsKey(eleitorId))
            {
                Console.WriteLine("❌ Eleitor não encontrado!");
                RegistrarFalhaLogin(eleitorId);
                return false;
            }

            if (credenciais[eleitorId] != senha) // Em produção: VerificarHash(senha, credenciais[eleitorId])
            {
                RegistrarFalhaLogin(eleitorId);
                int tentativasRestantes = MaxTentativas - (falhasLogin.ContainsKey(eleitorId) ? falhasLogin[eleitorId] : 0);

                if (tentativasRestantes > 0)
                {
                    Console.WriteLine($"❌ Senha incorreta! Tentativas restantes: {tentativasRestantes}");
                }
                else
                {
                    Console.WriteLine($"❌ Conta bloqueada por {MinutosBloqueio} minutos devido a múltiplas tentativas falhas!");
                }
                return false;
            }

            // Autenticação bem-sucedida
            LimparFalhasLogin(eleitorId);
            sessoesAtivas.Add(eleitorId);
            Console.WriteLine("✓ Autenticação realizada com sucesso!");
            return true;
        }

        public bool AutenticarInterativo()
        {
            Console.WriteLine("\n--- AUTENTICAÇÃO ---");
            Console.Write("ID do eleitor: ");
            string id = Console.ReadLine();

            Console.Write("Senha: ");
            string senha = LerSenhaOculta();
            Console.WriteLine();

            return Autenticar(id, senha);
        }

        private string LerSenhaOculta()
        {
            string senha = "";
            ConsoleKeyInfo key;

            do
            {
                key = Console.ReadKey(true);

                if (key.Key != ConsoleKey.Backspace && key.Key != ConsoleKey.Enter)
                {
                    senha += key.KeyChar;
                    Console.Write("*");
                }
                else if (key.Key == ConsoleKey.Backspace && senha.Length > 0)
                {
                    senha = senha.Substring(0, senha.Length - 1);
                    Console.Write("\b \b");
                }
            } while (key.Key != ConsoleKey.Enter);

            return senha;
        }

        public void Logout(string eleitorId)
        {
            if (sessoesAtivas.Contains(eleitorId))
            {
                sessoesAtivas.Remove(eleitorId);
                Console.WriteLine("✓ Sessão encerrada.");
            }
        }

        public bool EstaAutenticado(string eleitorId)
        {
            return sessoesAtivas.Contains(eleitorId);
        }

        private bool EstaBloqueado(string eleitorId)
        {
            if (!tentativasLogin.ContainsKey(eleitorId) || !falhasLogin.ContainsKey(eleitorId))
                return false;

            if (falhasLogin[eleitorId] < MaxTentativas)
                return false;

            var tempoDecorrido = DateTime.Now - tentativasLogin[eleitorId];
            return tempoDecorrido.TotalMinutes < MinutosBloqueio;
        }

        private TimeSpan ObterTempoRestanteBloqueio(string eleitorId)
        {
            if (!tentativasLogin.ContainsKey(eleitorId))
                return TimeSpan.Zero;

            var tempoDecorrido = DateTime.Now - tentativasLogin[eleitorId];
            var tempoRestante = TimeSpan.FromMinutes(MinutosBloqueio) - tempoDecorrido;
            return tempoRestante > TimeSpan.Zero ? tempoRestante : TimeSpan.Zero;
        }

        private void RegistrarFalhaLogin(string eleitorId)
        {
            tentativasLogin[eleitorId] = DateTime.Now;

            if (!falhasLogin.ContainsKey(eleitorId))
                falhasLogin[eleitorId] = 0;

            falhasLogin[eleitorId]++;
        }

        private void LimparFalhasLogin(string eleitorId)
        {
            if (falhasLogin.ContainsKey(eleitorId))
                falhasLogin.Remove(eleitorId);

            if (tentativasLogin.ContainsKey(eleitorId))
                tentativasLogin.Remove(eleitorId);
        }

        public void AlterarSenha(string eleitorId, string senhaAtual, string novaSenha)
        {
            if (!credenciais.ContainsKey(eleitorId))
            {
                Console.WriteLine("❌ Eleitor não encontrado!");
                return;
            }

            if (credenciais[eleitorId] != senhaAtual)
            {
                Console.WriteLine("❌ Senha atual incorreta!");
                return;
            }

            if (novaSenha.Length < 4)
            {
                Console.WriteLine("❌ Nova senha deve ter no mínimo 4 caracteres!");
                return;
            }

            credenciais[eleitorId] = novaSenha;
            Console.WriteLine("✓ Senha alterada com sucesso!");
        }
    }
}