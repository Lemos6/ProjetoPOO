﻿using System;
using System.IO;
using System.Text;
using System.Linq;

namespace ProjetoPOO
{
    public class BackupRestore
    {
        private const string PastaBackup = "backups";

        public BackupRestore()
        {
            if (!Directory.Exists(PastaBackup))
            {
                Directory.CreateDirectory(PastaBackup);
            }
        }

        public void CriarBackup(EleitoresLista eleitores, CandidatosLista candidatos, GestorEleicoes gestor)
        {
            try
            {
                string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
                string nomeArquivo = Path.Combine(PastaBackup, $"backup_{timestamp}.dat");

                using (StreamWriter writer = new StreamWriter(nomeArquivo, false, Encoding.UTF8))
                {
                    // Cabeçalho
                    writer.WriteLine("===== BACKUP SISTEMA VOTAÇÃO =====");
                    writer.WriteLine($"Data: {DateTime.Now:dd/MM/yyyy HH:mm:ss}");
                    writer.WriteLine();

                    // Backup Eleitores
                    writer.WriteLine("[ELEITORES]");
                    foreach (var eleitor in eleitores.ObterTodos())
                    {
                        writer.WriteLine($"{eleitor.Id}|{eleitor.Nome}|{eleitor.Idade}|{eleitor.JaVotou}");
                    }
                    writer.WriteLine();

                    // Backup Candidatos
                    writer.WriteLine("[CANDIDATOS]");
                    foreach (var candidato in candidatos.ObterCandidatos())
                    {
                        writer.WriteLine($"{candidato.Id}|{candidato.Nome}|{candidato.Idade}");
                    }
                    writer.WriteLine();

                    // Backup Eleições
                    writer.WriteLine("[ELEICOES]");
                    var todasEleicoes = gestor.ObterEleicoesAbertas()
                        .Concat(gestor.ObterEleicoesFuturas())
                        .Concat(gestor.ObterEleicoesEncerradas());

                    foreach (var eleicao in todasEleicoes)
                    {
                        writer.WriteLine($"{eleicao.Tipo}|{eleicao.Nome}|{eleicao.DataInicio:yyyy-MM-dd HH:mm}|{eleicao.DataFim:yyyy-MM-dd HH:mm}");

                        // Candidatos da eleição
                        writer.WriteLine("CANDIDATOS_ELEICAO:");
                        foreach (var candidato in eleicao.Candidatos)
                        {
                            writer.WriteLine($"  {candidato.Id}");
                        }

                        // Votos da eleição
                        writer.WriteLine("VOTOS_ELEICAO:");
                        foreach (var voto in eleicao.Votos)
                        {
                            writer.WriteLine($"  {voto.IdCandidato}|{voto.IdEleitor}|{voto.DataVoto:yyyy-MM-dd HH:mm:ss}");
                        }
                        writer.WriteLine("---");
                    }
                }

                Console.WriteLine($"✓ Backup criado com sucesso: {nomeArquivo}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Erro ao criar backup: {ex.Message}");
            }
        }

        public void ListarBackups()
        {
            Console.WriteLine("\n==========================================");
            Console.WriteLine("         BACKUPS DISPONÍVEIS");
            Console.WriteLine("==========================================");

            var arquivos = Directory.GetFiles(PastaBackup, "backup_*.dat")
                .OrderByDescending(f => f)
                .ToList();

            if (arquivos.Count == 0)
            {
                Console.WriteLine("Nenhum backup encontrado.");
                return;
            }

            for (int i = 0; i < arquivos.Count; i++)
            {
                var info = new FileInfo(arquivos[i]);
                Console.WriteLine($"[{i + 1}] {Path.GetFileName(arquivos[i])}");
                Console.WriteLine($"    Data: {info.CreationTime:dd/MM/yyyy HH:mm:ss}");
                Console.WriteLine($"    Tamanho: {info.Length / 1024.0:F2} KB");
                Console.WriteLine();
            }
        }

        public void RestaurarBackup(string nomeArquivo, EleitoresLista eleitores, CandidatosLista candidatos)
        {
            try
            {
                string caminho = Path.Combine(PastaBackup, nomeArquivo);

                if (!File.Exists(caminho))
                {
                    Console.WriteLine("❌ Arquivo de backup não encontrado!");
                    return;
                }

                Console.WriteLine("\n⚠️  ATENÇÃO: Esta operação irá substituir todos os dados atuais!");
                Console.Write("Deseja continuar? (S/N): ");

                if (Console.ReadLine()?.ToUpper() != "S")
                {
                    Console.WriteLine("Operação cancelada.");
                    return;
                }

                // Ler e restaurar dados
                using (StreamReader reader = new StreamReader(caminho, Encoding.UTF8))
                {
                    string linha;
                    string secao = "";

                    while ((linha = reader.ReadLine()) != null)
                    {
                        if (linha.StartsWith("[ELEITORES]"))
                        {
                            secao = "ELEITORES";
                            continue;
                        }
                        else if (linha.StartsWith("[CANDIDATOS]"))
                        {
                            secao = "CANDIDATOS";
                            continue;
                        }
                        else if (linha.StartsWith("[ELEICOES]"))
                        {
                            secao = "ELEICOES";
                            continue;
                        }

                        if (string.IsNullOrWhiteSpace(linha)) continue;

                        // Processar linha baseado na seção
                        if (secao == "ELEITORES" && linha.Contains("|"))
                        {
                            var partes = linha.Split('|');
                            // Processar eleitor (implementar lógica de restauração)
                        }
                        else if (secao == "CANDIDATOS" && linha.Contains("|"))
                        {
                            var partes = linha.Split('|');
                            // Processar candidato
                        }
                    }
                }

                Console.WriteLine("✓ Backup restaurado com sucesso!");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Erro ao restaurar backup: {ex.Message}");
            }
        }

        public void ExportarRelatorioCSV(GestorEleicoes gestor, string nomeArquivo)
        {
            try
            {
                string caminho = Path.Combine(PastaBackup, nomeArquivo);

                using (StreamWriter writer = new StreamWriter(caminho, false, Encoding.UTF8))
                {
                    writer.WriteLine("Tipo;Nome;Data Início;Data Fim;Total Votos;Candidatos");

                    var todasEleicoes = gestor.ObterEleicoesAbertas()
                        .Concat(gestor.ObterEleicoesFuturas())
                        .Concat(gestor.ObterEleicoesEncerradas());

                    foreach (var eleicao in todasEleicoes)
                    {
                        writer.WriteLine($"{eleicao.Tipo};{eleicao.Nome};{eleicao.DataInicio:dd/MM/yyyy};{eleicao.DataFim:dd/MM/yyyy};{eleicao.Votos.Count};{eleicao.Candidatos.Count}");
                    }
                }

                Console.WriteLine($"✓ Relatório CSV exportado: {caminho}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Erro ao exportar CSV: {ex.Message}");
            }
        }
    }
}