﻿using System;

namespace ProjetoPOO
{
    public class Candidato
    {
        private int _id;
        private string _nome;
        private int _idade;

        public int Id
        {
            get => _id;
            set
            {
                if (value <= 0)
                    throw new ArgumentException("ID deve ser maior que zero.");
                _id = value;
            }
        }

        public string Nome
        {
            get => _nome;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Nome não pode estar vazio.");
                _nome = value;
            }
        }

        public int Idade
        {
            get => _idade;
            set
            {
                if (value < 0 || value > 150)
                    throw new ArgumentException("Idade inválida.");
                _idade = value;
            }
        }

        private const int IdadeMinimaCandidatura = 35;

        public bool ElegivelParaCandidatar()
        {
            return Idade >= IdadeMinimaCandidatura;
        }

        public override string ToString()
        {
            return $"ID: {Id} - {Nome} ({Idade} anos)";
        }
    }
}