﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ProjetoPOO
{
    public class CandidatosLista
    {
        private List<Candidato> candidatos;

        public CandidatosLista()
        {
            candidatos = new List<Candidato>();
            InicializarDadosExemplo();
        }

        private void InicializarDadosExemplo()
        {
            // Candidatos elegíveis (idade >= 35)
            AdicionarCandidato(new Candidato { Id = 1, Nome = "Diana Pinto", Idade = 42 });
            AdicionarCandidato(new Candidato { Id = 3, Nome = "Carlos Pereira", Idade = 50 });
            AdicionarCandidato(new Candidato { Id = 4, Nome = "Daniela Souza", Idade = 37 });
            AdicionarCandidato(new Candidato { Id = 6, Nome = "Fernando Rodrigues", Idade = 45 });
            AdicionarCandidato(new Candidato { Id = 7, Nome = "Gabriela Santos", Idade = 38 });
            AdicionarCandidato(new Candidato { Id = 8, Nome = "Helena Martins", Idade = 52 });
            AdicionarCandidato(new Candidato { Id = 9, Nome = "Igor Almeida", Idade = 41 });
            AdicionarCandidato(new Candidato { Id = 10, Nome = "Juliana Fernandes", Idade = 36 });
            AdicionarCandidato(new Candidato { Id = 11, Nome = "Lucas Oliveira", Idade = 48 });
            AdicionarCandidato(new Candidato { Id = 12, Nome = "Mariana Silva", Idade = 39 });
            AdicionarCandidato(new Candidato { Id = 13, Nome = "Nuno Carvalho", Idade = 55 });
            AdicionarCandidato(new Candidato { Id = 14, Nome = "Patrícia Gomes", Idade = 43 });
            AdicionarCandidato(new Candidato { Id = 15, Nome = "Ricardo Mendes", Idade = 47 });
            AdicionarCandidato(new Candidato { Id = 16, Nome = "Sofia Ribeiro", Idade = 40 });
            AdicionarCandidato(new Candidato { Id = 17, Nome = "Tiago Costa", Idade = 35 });
            AdicionarCandidato(new Candidato { Id = 18, Nome = "Vanessa Lima", Idade = 44 });

            // Candidatos não elegíveis (idade < 35)
            AdicionarCandidato(new Candidato { Id = 2, Nome = "Bruno Costa", Idade = 34 });
            AdicionarCandidato(new Candidato { Id = 5, Nome = "Eduardo Lima", Idade = 29 });
            AdicionarCandidato(new Candidato { Id = 19, Nome = "William Santos", Idade = 32 });
            AdicionarCandidato(new Candidato { Id = 20, Nome = "Yara Ferreira", Idade = 28 });
        }

        public void AdicionarCandidato(Candidato candidato)
        {
            if (candidato == null)
                throw new ArgumentNullException(nameof(candidato));

            if (candidatos.Any(c => c.Id == candidato.Id))
                throw new InvalidOperationException($"Candidato com ID {candidato.Id} já existe.");

            candidatos.Add(candidato);
        }

        public void RemoverCandidato(int id)
        {
            var candidato = candidatos.FirstOrDefault(c => c.Id == id);
            if (candidato == null)
                throw new InvalidOperationException($"Candidato com ID {id} não encontrado.");

            candidatos.Remove(candidato);
        }

        public Candidato ObterPorId(int id)
        {
            return candidatos.FirstOrDefault(c => c.Id == id);
        }

        public List<Candidato> ObterCandidatos()
        {
            return candidatos;
        }

        public List<Candidato> ObterCandidatosElegiveis()
        {
            return candidatos.Where(c => c.ElegivelParaCandidatar()).ToList();
        }

        public int ContarTotal()
        {
            return candidatos.Count;
        }

        public int ContarElegiveis()
        {
            return candidatos.Count(c => c.ElegivelParaCandidatar());
        }
    }
}