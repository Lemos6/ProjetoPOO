﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ProjetoPOO
{
    public abstract class Eleicao
    {
        public string Nome { get; protected set; }
        public TipoEleicao Tipo { get; protected set; }
        public DateTime DataInicio { get; protected set; }
        public DateTime DataFim { get; protected set; }
        public List<Candidato> Candidatos { get; protected set; } = new List<Candidato>();
        public List<Voto> Votos { get; protected set; } = new List<Voto>();

        protected Eleicao(TipoEleicao tipo, DateTime inicio, DateTime fim)
        {
            if (fim <= inicio)
                throw new ArgumentException("A data de fim deve ser posterior à data de início.");

            Tipo = tipo;
            Nome = GerarNome(tipo);
            DataInicio = inicio;
            DataFim = fim;
        }

        private string GerarNome(TipoEleicao tipo)
        {
            switch (tipo)
            {
                case TipoEleicao.Presidencial:
                    return "Eleição Presidencial";
                case TipoEleicao.Assembleia:
                    return "Eleição para a Assembleia";
                case TipoEleicao.Municipal:
                    return "Eleição Municipal";
                default:
                    return "Eleição";
            }
        }

        public bool VotacaoAberta()
        {
            DateTime agora = DateTime.Now;
            return agora >= DataInicio && agora <= DataFim;
        }

        public abstract int QuorumMinimo();

        public void AdicionarCandidato(Candidato candidato)
        {
            if (candidato == null)
                throw new ArgumentNullException(nameof(candidato));

            if (!candidato.ElegivelParaCandidatar())
                throw new CandidatoNaoElegivelException(candidato.Nome);

            if (Candidatos.Any(c => c.Id == candidato.Id))
                throw new InvalidOperationException($"Candidato com ID {candidato.Id} já está registrado.");

            Candidatos.Add(candidato);
        }

        public void RegistarVoto(Candidato candidato, Eleitor eleitor)
        {
            if (!VotacaoAberta())
                throw new VotacaoEncerradaException();

            if (!eleitor.ElegivelParaVotar)
                throw new EleitorNaoElegivelException(
                    eleitor.JaVotou ? "Já votou" : "Não tem idade mínima");

            if (!candidato.ElegivelParaCandidatar())
                throw new CandidatoNaoElegivelException(candidato.Nome);

            if (!Candidatos.Any(c => c.Id == candidato.Id))
                throw new InvalidOperationException("Candidato não está registrado nesta eleição.");

            var voto = new Voto(candidato.Id, eleitor.Id, this.Tipo);
            Votos.Add(voto);
            eleitor.MarcarComoVotou();
        }

        public Dictionary<int, int> ObterResultados()
        {
            return Votos
                .GroupBy(v => v.IdCandidato)
                .ToDictionary(g => g.Key, g => g.Count());
        }

        public bool QuorumAtingido(int totalEleitores)
        {
            if (totalEleitores <= 0)
                return false;

            double percentualParticipacao = (Votos.Count * 100.0) / totalEleitores;
            return percentualParticipacao >= QuorumMinimo();
        }
    }
}