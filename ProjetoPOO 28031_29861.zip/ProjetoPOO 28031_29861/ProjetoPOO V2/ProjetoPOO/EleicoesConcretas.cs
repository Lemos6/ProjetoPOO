﻿using System;

namespace ProjetoPOO
{
    public class EleicaoPresidencial : Eleicao
    {
        public EleicaoPresidencial(DateTime inicio, DateTime fim)
            : base(TipoEleicao.Presidencial, inicio, fim)
        {
        }

        public override int QuorumMinimo()
        {
            return 50; // 50% dos eleitores registrados
        }
    }

    public class EleicaoAssembleia : Eleicao
    {
        public EleicaoAssembleia(DateTime inicio, DateTime fim)
            : base(TipoEleicao.Assembleia, inicio, fim)
        {
        }

        public override int QuorumMinimo()
        {
            return 33; // 33% dos eleitores registrados
        }
    }

    public class EleicaoMunicipal : Eleicao
    {
        public string Municipio { get; set; }

        public EleicaoMunicipal(DateTime inicio, DateTime fim, string municipio = "")
            : base(TipoEleicao.Municipal, inicio, fim)
        {
            Municipio = municipio;
            if (!string.IsNullOrWhiteSpace(municipio))
            {
                Nome = $"Eleição Municipal - {municipio}";
            }
        }

        public override int QuorumMinimo()
        {
            return 25; // 25% dos eleitores registrados
        }
    }
}