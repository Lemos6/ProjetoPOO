﻿using System;

namespace ProjetoPOO
{
    public class Eleitor
    {
        private string _id;
        private string _nome;
        private int _idade;

        public string Id
        {
            get => _id;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("ID não pode estar vazio.");
                _id = value;
            }
        }

        public string Nome
        {
            get => _nome;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Nome não pode estar vazio.");
                _nome = value;
            }
        }

        public int Idade
        {
            get => _idade;
            set
            {
                if (value < 0 || value > 150)
                    throw new ArgumentException("Idade inválida.");
                _idade = value;
            }
        }

        private const int IdadeMinimaVotacao = 18;

        public bool PodeVotar => Idade >= IdadeMinimaVotacao;
        public bool JaVotou { get; set; }
        public bool ElegivelParaVotar => PodeVotar && !JaVotou;

        public void MarcarComoVotou()
        {
            if (JaVotou)
                throw new InvalidOperationException($"{Nome} já votou.");
            if (!PodeVotar)
                throw new InvalidOperationException($"{Nome} não tem idade para votar.");

            JaVotou = true;
        }

        public override string ToString()
        {
            return $"ID: {Id} - {Nome} ({Idade} anos)";
        }
    }
}