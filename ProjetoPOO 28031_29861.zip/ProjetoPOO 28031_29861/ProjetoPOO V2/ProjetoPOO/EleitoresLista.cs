﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ProjetoPOO
{
    public class EleitoresLista
    {
        private List<Eleitor> eleitores;

        public EleitoresLista()
        {
            eleitores = new List<Eleitor>();
            InicializarDadosExemplo();
        }

        private void InicializarDadosExemplo()
        {
            AdicionarEleitor(new Eleitor { Id = "E001", Nome = "João Silva", Idade = 25, JaVotou = false });
            AdicionarEleitor(new Eleitor { Id = "E002", Nome = "Maria Oliveira", Idade = 17, JaVotou = false });
            AdicionarEleitor(new Eleitor { Id = "E003", Nome = "Pedro Santos", Idade = 30, JaVotou = false });
            AdicionarEleitor(new Eleitor { Id = "E004", Nome = "Ana Costa", Idade = 22, JaVotou = false });
            AdicionarEleitor(new Eleitor { Id = "E005", Nome = "Lucas Pereira", Idade = 16, JaVotou = false });
            AdicionarEleitor(new Eleitor { Id = "E006", Nome = "Beatriz Sousa", Idade = 28, JaVotou = false });
            AdicionarEleitor(new Eleitor { Id = "E007", Nome = "Carlos Mendes", Idade = 35, JaVotou = false });
            AdicionarEleitor(new Eleitor { Id = "E008", Nome = "Débora Alves", Idade = 42, JaVotou = false });
            AdicionarEleitor(new Eleitor { Id = "E009", Nome = "Emanuel Rocha", Idade = 19, JaVotou = false });
            AdicionarEleitor(new Eleitor { Id = "E010", Nome = "Fernanda Dias", Idade = 31, JaVotou = false });
            AdicionarEleitor(new Eleitor { Id = "E011", Nome = "Gustavo Pinto", Idade = 27, JaVotou = false });
            AdicionarEleitor(new Eleitor { Id = "E012", Nome = "Helena Barros", Idade = 15, JaVotou = false });
            AdicionarEleitor(new Eleitor { Id = "E013", Nome = "Inês Cardoso", Idade = 38, JaVotou = false });
            AdicionarEleitor(new Eleitor { Id = "E014", Nome = "José Tavares", Idade = 45, JaVotou = false });
            AdicionarEleitor(new Eleitor { Id = "E015", Nome = "Kátia Nunes", Idade = 23, JaVotou = false });
        }

        public void AdicionarEleitor(Eleitor eleitor)
        {
            if (eleitor == null)
                throw new ArgumentNullException(nameof(eleitor));

            if (eleitores.Any(e => e.Id == eleitor.Id))
                throw new InvalidOperationException($"Eleitor com Id '{eleitor.Id}' já existe.");

            eleitores.Add(eleitor);
        }

        public void RemoverEleitor(string id)
        {
            var eleitor = eleitores.FirstOrDefault(e => e.Id == id);
            if (eleitor == null)
                throw new InvalidOperationException($"Eleitor com ID {id} não encontrado.");

            eleitores.Remove(eleitor);
        }

        public Eleitor ObterPorId(string id)
        {
            return eleitores.FirstOrDefault(e => e.Id == id);
        }

        public IReadOnlyList<Eleitor> ObterTodos()
        {
            return eleitores.AsReadOnly();
        }

        public List<Eleitor> ObterElegiveis()
        {
            return eleitores.Where(e => e.ElegivelParaVotar).ToList();
        }

        public int ContarTotal()
        {
            return eleitores.Count;
        }

        public int ContarElegiveis()
        {
            return eleitores.Count(e => e.ElegivelParaVotar);
        }

        public int ContarQueVotaram()
        {
            return eleitores.Count(e => e.JaVotou);
        }

        public void ReiniciarVotos()
        {
            foreach (var eleitor in eleitores)
            {
                eleitor.JaVotou = false;
            }
        }
    }
}