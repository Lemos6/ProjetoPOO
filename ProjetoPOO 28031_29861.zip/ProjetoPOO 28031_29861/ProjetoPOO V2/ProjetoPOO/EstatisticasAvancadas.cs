﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ProjetoPOO
{
    public class EstatisticasAvancadas
    {
        public void GerarDashboard(GestorEleicoes gestor, EleitoresLista eleitores, CandidatosLista candidatos)
        {
            Console.Clear();
            Console.WriteLine("╔════════════════════════════════════════════════════════════╗");
            Console.WriteLine("║                    DASHBOARD GERAL                         ║");
            Console.WriteLine("╚════════════════════════════════════════════════════════════╝");

            MostrarResumoGeral(gestor, eleitores, candidatos);
            MostrarGraficoParticipacao(eleitores);
            MostrarTendencias(gestor);
            MostrarRankingCandidatos(gestor, candidatos);
        }

        private void MostrarResumoGeral(GestorEleicoes gestor, EleitoresLista eleitores, CandidatosLista candidatos)
        {
            Console.WriteLine("\n📊 RESUMO GERAL");
            Console.WriteLine("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

            var eleicoesAbertas = gestor.ObterEleicoesAbertas();
            var eleicoesFuturas = gestor.ObterEleicoesFuturas();
            var eleicoesEncerradas = gestor.ObterEleicoesEncerradas();

            Console.WriteLine($"🗳️  Eleições Abertas: {eleicoesAbertas.Count}");
            Console.WriteLine($"📅 Eleições Futuras: {eleicoesFuturas.Count}");
            Console.WriteLine($"✓  Eleições Encerradas: {eleicoesEncerradas.Count}");
            Console.WriteLine($"👥 Total de Eleitores: {eleitores.ContarTotal()}");
            Console.WriteLine($"✓  Eleitores que Votaram: {eleitores.ContarQueVotaram()}");
            Console.WriteLine($"👤 Total de Candidatos: {candidatos.ContarTotal()}");
            Console.WriteLine($"✓  Candidatos Elegíveis: {candidatos.ContarElegiveis()}");
        }

        private void MostrarGraficoParticipacao(EleitoresLista eleitores)
        {
            Console.WriteLine("\n📈 PARTICIPAÇÃO ELEITORAL");
            Console.WriteLine("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

            int total = eleitores.ContarTotal();
            int votaram = eleitores.ContarQueVotaram();
            int naoVotaram = total - votaram;

            double percentualVotaram = total > 0 ? (votaram * 100.0 / total) : 0;
            double percentualNaoVotaram = total > 0 ? (naoVotaram * 100.0 / total) : 0;

            Console.WriteLine($"\nVotaram:     {GerarBarraHorizontal(percentualVotaram, 40)} {votaram} ({percentualVotaram:F1}%)");
            Console.WriteLine($"Não votaram: {GerarBarraHorizontal(percentualNaoVotaram, 40)} {naoVotaram} ({percentualNaoVotaram:F1}%)");
        }

        private void MostrarTendencias(GestorEleicoes gestor)
        {
            Console.WriteLine("\n📉 TENDÊNCIAS");
            Console.WriteLine("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

            var todasEleicoes = gestor.ObterEleicoesAbertas()
                .Concat(gestor.ObterEleicoesEncerradas())
                .OrderByDescending(e => e.Votos.Count)
                .Take(3);

            Console.WriteLine("\nTop 3 Eleições por Participação:");
            int pos = 1;
            foreach (var eleicao in todasEleicoes)
            {
                Console.WriteLine($"{pos}. {eleicao.Nome}: {eleicao.Votos.Count} votos");
                pos++;
            }
        }

        private void MostrarRankingCandidatos(GestorEleicoes gestor, CandidatosLista candidatos)
        {
            Console.WriteLine("\n🏆 RANKING GLOBAL DE CANDIDATOS");
            Console.WriteLine("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

            var todosVotos = new Dictionary<int, int>();

            var todasEleicoes = gestor.ObterEleicoesAbertas()
                .Concat(gestor.ObterEleicoesEncerradas());

            foreach (var eleicao in todasEleicoes)
            {
                var resultados = eleicao.ObterResultados();
                foreach (var resultado in resultados)
                {
                    if (!todosVotos.ContainsKey(resultado.Key))
                        todosVotos[resultado.Key] = 0;
                    todosVotos[resultado.Key] += resultado.Value;
                }
            }

            var ranking = todosVotos
                .OrderByDescending(v => v.Value)
                .Take(5);

            int posicao = 1;
            foreach (var voto in ranking)
            {
                var candidato = candidatos.ObterPorId(voto.Key);
                if (candidato != null)
                {
                    string medalha = posicao == 1 ? "🥇" : posicao == 2 ? "🥈" : posicao == 3 ? "🥉" : "  ";
                    Console.WriteLine($"{medalha} {posicao}º {candidato.Nome}: {voto.Value} votos");
                    posicao++;
                }
            }
        }

        private string GerarBarraHorizontal(double percentual, int largura)
        {
            int preenchido = (int)(largura * percentual / 100);
            return new string('█', preenchido) + new string('░', largura - preenchido);
        }

        public void CompararEleicoes(Eleicao eleicao1, Eleicao eleicao2)
        {
            Console.WriteLine("\n╔════════════════════════════════════════════════════════════╗");
            Console.WriteLine("║              COMPARAÇÃO ENTRE ELEIÇÕES                     ║");
            Console.WriteLine("╚════════════════════════════════════════════════════════════╝");

            Console.WriteLine($"\n📊 {eleicao1.Nome} vs {eleicao2.Nome}");
            Console.WriteLine("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

            Console.WriteLine($"\nTotal de Votos:");
            Console.WriteLine($"  {eleicao1.Nome}: {eleicao1.Votos.Count}");
            Console.WriteLine($"  {eleicao2.Nome}: {eleicao2.Votos.Count}");

            Console.WriteLine($"\nCandidatos:");
            Console.WriteLine($"  {eleicao1.Nome}: {eleicao1.Candidatos.Count}");
            Console.WriteLine($"  {eleicao2.Nome}: {eleicao2.Candidatos.Count}");

            Console.WriteLine($"\nQuórum Mínimo:");
            Console.WriteLine($"  {eleicao1.Nome}: {eleicao1.QuorumMinimo()}%");
            Console.WriteLine($"  {eleicao2.Nome}: {eleicao2.QuorumMinimo()}%");
        }

        public void AnalisarPorIdade(EleitoresLista eleitores)
        {
            Console.WriteLine("\n📊 ANÁLISE POR FAIXA ETÁRIA");
            Console.WriteLine("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

            var todosEleitores = eleitores.ObterTodos();

            var faixas = new Dictionary<string, int>
            {
                { "Menores de 18", todosEleitores.Count(e => e.Idade < 18) },
                { "18-25 anos", todosEleitores.Count(e => e.Idade >= 18 && e.Idade <= 25) },
                { "26-35 anos", todosEleitores.Count(e => e.Idade >= 26 && e.Idade <= 35) },
                { "36-50 anos", todosEleitores.Count(e => e.Idade >= 36 && e.Idade <= 50) },
                { "Acima de 50", todosEleitores.Count(e => e.Idade > 50) }
            };

            foreach (var faixa in faixas)
            {
                double percentual = todosEleitores.Count > 0 ? (faixa.Value * 100.0 / todosEleitores.Count) : 0;
                Console.WriteLine($"{faixa.Key,-15}: {GerarBarraHorizontal(percentual, 30)} {faixa.Value} ({percentual:F1}%)");
            }
        }

        public void PreverResultado(Eleicao eleicao, int totalEleitoresElegiveis)
        {
            Console.WriteLine($"\n🔮 PREVISÃO DE RESULTADO - {eleicao.Nome}");
            Console.WriteLine("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

            var resultados = eleicao.ObterResultados();
            int totalVotos = resultados.Values.Sum();

            if (totalVotos == 0)
            {
                Console.WriteLine("Ainda não há votos para fazer previsão.");
                return;
            }

            double taxaParticipacao = totalEleitoresElegiveis > 0 ? (totalVotos * 100.0 / totalEleitoresElegiveis) : 0;
            Console.WriteLine($"\nParticipação atual: {taxaParticipacao:F1}%");
            Console.WriteLine($"Votos registrados: {totalVotos} de {totalEleitoresElegiveis}");

            Console.WriteLine("\nProjeção se mantiver tendência atual:");
            var ordenados = resultados.OrderByDescending(r => r.Value).Take(3);

            foreach (var resultado in ordenados)
            {
                var candidato = eleicao.Candidatos.FirstOrDefault(c => c.Id == resultado.Key);
                if (candidato != null)
                {
                    double percentualAtual = totalVotos > 0 ? (resultado.Value * 100.0 / totalVotos) : 0;
                    int votosProjetados = (int)(totalEleitoresElegiveis * percentualAtual / 100);
                    Console.WriteLine($"  {candidato.Nome}: {percentualAtual:F1}% (projeção: ~{votosProjetados} votos)");
                }
            }
        }
    }
}