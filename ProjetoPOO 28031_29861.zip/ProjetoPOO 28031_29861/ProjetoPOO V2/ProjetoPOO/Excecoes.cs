﻿using System;

namespace ProjetoPOO
{
    public class VotacaoEncerradaException : Exception
    {
        public VotacaoEncerradaException()
            : base("A votação está encerrada.") { }

        public VotacaoEncerradaException(string mensagem)
            : base(mensagem) { }
    }

    public class EleitorJaVotouException : Exception
    {
        public EleitorJaVotouException(string nomeEleitor)
            : base($"O eleitor {nomeEleitor} já votou nesta eleição.") { }
    }

    public class EleitorNaoElegivelException : Exception
    {
        public EleitorNaoElegivelException(string motivo)
            : base($"Eleitor não elegível: {motivo}") { }
    }

    public class CandidatoNaoElegivelException : Exception
    {
        public CandidatoNaoElegivelException(string nomeCandidato)
            : base($"O candidato {nomeCandidato} não é elegível para esta eleição.") { }
    }
}