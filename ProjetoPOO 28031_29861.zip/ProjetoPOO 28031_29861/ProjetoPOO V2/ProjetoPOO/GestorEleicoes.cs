﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ProjetoPOO
{
    public class GestorEleicoes
    {
        private List<Eleicao> eleicoes;
        private Eleicao eleicaoAtiva;

        public GestorEleicoes()
        {
            eleicoes = new List<Eleicao>();
            InicializarEleicoesExemplo();
        }

        private void InicializarEleicoesExemplo()
        {
            // Eleição Presidencial - Aberta agora
            var presidencial = new EleicaoPresidencial(
                DateTime.Now.AddDays(-1),
                DateTime.Now.AddDays(7));
            eleicoes.Add(presidencial);

            // Eleição Assembleia - Futura
            var assembleia = new EleicaoAssembleia(
                DateTime.Now.AddDays(10),
                DateTime.Now.AddDays(17));
            eleicoes.Add(assembleia);

            // Eleição Municipal - Encerrada
            var municipal = new EleicaoMunicipal(
                DateTime.Now.AddDays(-15),
                DateTime.Now.AddDays(-8),
                "Bragança");
            eleicoes.Add(municipal);
        }

        public void CriarNovaEleicao()
        {
            Console.WriteLine("\n==========================================");
            Console.WriteLine("         CRIAR NOVA ELEIÇÃO");
            Console.WriteLine("==========================================");

            Console.WriteLine("Tipos de eleição:");
            Console.WriteLine("1. Presidencial");
            Console.WriteLine("2. Assembleia");
            Console.WriteLine("3. Municipal");
            Console.Write("\nEscolha o tipo: ");

            if (!int.TryParse(Console.ReadLine(), out int tipo) || tipo < 1 || tipo > 3)
            {
                Console.WriteLine("❌ Tipo inválido!");
                return;
            }

            Console.Write("\nData de início (dd/MM/yyyy HH:mm): ");
            if (!DateTime.TryParse(Console.ReadLine(), out DateTime inicio))
            {
                Console.WriteLine("❌ Data inválida!");
                return;
            }

            Console.Write("Data de fim (dd/MM/yyyy HH:mm): ");
            if (!DateTime.TryParse(Console.ReadLine(), out DateTime fim))
            {
                Console.WriteLine("❌ Data inválida!");
                return;
            }

            try
            {
                Eleicao novaEleicao = null;

                switch (tipo)
                {
                    case 1:
                        novaEleicao = new EleicaoPresidencial(inicio, fim);
                        break;
                    case 2:
                        novaEleicao = new EleicaoAssembleia(inicio, fim);
                        break;
                    case 3:
                        Console.Write("Nome do município: ");
                        string municipio = Console.ReadLine();
                        novaEleicao = new EleicaoMunicipal(inicio, fim, municipio);
                        break;
                }

                eleicoes.Add(novaEleicao);
                Console.WriteLine($"\n✓ Eleição '{novaEleicao.Nome}' criada com sucesso!");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Erro ao criar eleição: {ex.Message}");
            }
        }

        public void ListarEleicoes()
        {
            Console.WriteLine("\n==========================================");
            Console.WriteLine("         TODAS AS ELEIÇÕES");
            Console.WriteLine("==========================================");

            if (eleicoes.Count == 0)
            {
                Console.WriteLine("Nenhuma eleição registrada.");
                return;
            }

            for (int i = 0; i < eleicoes.Count; i++)
            {
                var eleicao = eleicoes[i];
                string status = ObterStatusEleicao(eleicao);

                Console.WriteLine($"\n[{i + 1}] {eleicao.Nome}");
                Console.WriteLine($"    Tipo: {eleicao.Tipo}");
                Console.WriteLine($"    Status: {status}");
                Console.WriteLine($"    Início: {eleicao.DataInicio:dd/MM/yyyy HH:mm}");
                Console.WriteLine($"    Fim: {eleicao.DataFim:dd/MM/yyyy HH:mm}");
                Console.WriteLine($"    Candidatos: {eleicao.Candidatos.Count}");
                Console.WriteLine($"    Votos: {eleicao.Votos.Count}");
                Console.WriteLine($"    Quórum mínimo: {eleicao.QuorumMinimo()}%");
                Console.WriteLine("------------------------------------------");
            }
        }

        public Eleicao SelecionarEleicao()
        {
            Console.WriteLine("\n==========================================");
            Console.WriteLine("         SELECIONAR ELEIÇÃO");
            Console.WriteLine("==========================================");

            var eleicoesAbertas = eleicoes.Where(e => e.VotacaoAberta()).ToList();

            if (eleicoesAbertas.Count == 0)
            {
                Console.WriteLine("❌ Não há eleições abertas no momento.");
                return null;
            }

            Console.WriteLine("Eleições disponíveis para votação:\n");

            for (int i = 0; i < eleicoesAbertas.Count; i++)
            {
                var eleicao = eleicoesAbertas[i];
                Console.WriteLine($"[{i + 1}] {eleicao.Nome}");
                Console.WriteLine($"    Encerra em: {eleicao.DataFim:dd/MM/yyyy HH:mm}");
                Console.WriteLine($"    Candidatos: {eleicao.Candidatos.Count}");
                Console.WriteLine($"    Votos registrados: {eleicao.Votos.Count}");
                Console.WriteLine();
            }

            Console.Write("Escolha a eleição (número): ");
            if (!int.TryParse(Console.ReadLine(), out int escolha) ||
                escolha < 1 || escolha > eleicoesAbertas.Count)
            {
                Console.WriteLine("❌ Opção inválida!");
                return null;
            }

            eleicaoAtiva = eleicoesAbertas[escolha - 1];
            Console.WriteLine($"\n✓ Eleição selecionada: {eleicaoAtiva.Nome}");
            return eleicaoAtiva;
        }

        public void AdicionarCandidatoAEleicao(CandidatosLista listaCandidatos)
        {
            if (eleicaoAtiva == null)
            {
                Console.WriteLine("❌ Nenhuma eleição selecionada!");
                return;
            }

            Console.WriteLine($"\n--- Adicionar candidato à {eleicaoAtiva.Nome} ---");

            var candidatosElegiveis = listaCandidatos.ObterCandidatosElegiveis();

            if (candidatosElegiveis.Count == 0)
            {
                Console.WriteLine("❌ Não há candidatos elegíveis.");
                return;
            }

            Console.WriteLine("\nCandidatos elegíveis disponíveis:");
            for (int i = 0; i < candidatosElegiveis.Count; i++)
            {
                var c = candidatosElegiveis[i];
                bool jaRegistrado = eleicaoAtiva.Candidatos.Any(ec => ec.Id == c.Id);
                string status = jaRegistrado ? "(Já registrado)" : "";
                Console.WriteLine($"[{i + 1}] {c.Nome} - {c.Idade} anos {status}");
            }

            Console.Write("\nEscolha o candidato (número): ");
            if (!int.TryParse(Console.ReadLine(), out int escolha) ||
                escolha < 1 || escolha > candidatosElegiveis.Count)
            {
                Console.WriteLine("❌ Opção inválida!");
                return;
            }

            try
            {
                var candidato = candidatosElegiveis[escolha - 1];
                eleicaoAtiva.AdicionarCandidato(candidato);
                Console.WriteLine($"✓ {candidato.Nome} adicionado à eleição!");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ {ex.Message}");
            }
        }

        public List<Eleicao> ObterEleicoesAbertas()
        {
            return eleicoes.Where(e => e.VotacaoAberta()).ToList();
        }

        public List<Eleicao> ObterEleicoesFuturas()
        {
            return eleicoes.Where(e => DateTime.Now < e.DataInicio).ToList();
        }

        public List<Eleicao> ObterEleicoesEncerradas()
        {
            return eleicoes.Where(e => DateTime.Now > e.DataFim).ToList();
        }

        public Eleicao ObterEleicaoAtiva()
        {
            return eleicaoAtiva;
        }

        public void DefinirEleicaoAtiva(int indice)
        {
            if (indice >= 0 && indice < eleicoes.Count)
            {
                eleicaoAtiva = eleicoes[indice];
            }
        }

        private string ObterStatusEleicao(Eleicao eleicao)
        {
            if (eleicao.VotacaoAberta())
                return "🟢 ABERTA";
            else if (DateTime.Now < eleicao.DataInicio)
                return "🟡 FUTURA";
            else
                return "🔴 ENCERRADA";
        }

        public void GerarRelatorioEleicao(Eleicao eleicao, EleitoresLista eleitores)
        {
            Console.WriteLine("\n================================================");
            Console.WriteLine($"    RELATÓRIO: {eleicao.Nome}");
            Console.WriteLine("================================================");

            Console.WriteLine($"\nTipo: {eleicao.Tipo}");
            Console.WriteLine($"Status: {ObterStatusEleicao(eleicao)}");
            Console.WriteLine($"Período: {eleicao.DataInicio:dd/MM/yyyy} a {eleicao.DataFim:dd/MM/yyyy}");
            Console.WriteLine($"Quórum mínimo: {eleicao.QuorumMinimo()}%");

            var resultados = eleicao.ObterResultados();
            int totalVotos = resultados.Values.Sum();

            Console.WriteLine($"\n--- PARTICIPAÇÃO ---");
            Console.WriteLine($"Total de votos: {totalVotos}");
            Console.WriteLine($"Candidatos registrados: {eleicao.Candidatos.Count}");

            int totalEleitores = eleitores.ContarTotal();
            bool quorumAtingido = eleicao.QuorumAtingido(totalEleitores);

            Console.WriteLine($"Quórum atingido: {(quorumAtingido ? "✓ SIM" : "✗ NÃO")}");

            if (resultados.Count > 0)
            {
                Console.WriteLine($"\n--- RESULTADOS ---");
                var ordenados = resultados.OrderByDescending(r => r.Value);

                int posicao = 1;
                foreach (var resultado in ordenados)
                {
                    var candidato = eleicao.Candidatos.FirstOrDefault(c => c.Id == resultado.Key);
                    if (candidato != null)
                    {
                        double percentual = totalVotos > 0 ? (resultado.Value * 100.0 / totalVotos) : 0;
                        Console.WriteLine($"{posicao}º - {candidato.Nome}: {resultado.Value} votos ({percentual:F1}%)");
                        posicao++;
                    }
                }
            }
        }
    }
}