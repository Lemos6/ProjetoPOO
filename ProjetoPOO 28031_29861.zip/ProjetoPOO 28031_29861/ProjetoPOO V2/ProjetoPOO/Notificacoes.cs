﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ProjetoPOO
{
    public enum PrioridadeNotificacao
    {
        Baixa,
        Media,
        Alta,
        Urgente
    }

    public class Notificacao
    {
        public Guid Id { get; set; }
        public string Titulo { get; set; }
        public string Mensagem { get; set; }
        public DateTime DataCriacao { get; set; }
        public PrioridadeNotificacao Prioridade { get; set; }
        public bool Lida { get; set; }
        public string DestinatarioId { get; set; }

        public Notificacao(string titulo, string mensagem, PrioridadeNotificacao prioridade, string destinatarioId = null)
        {
            Id = Guid.NewGuid();
            Titulo = titulo;
            Mensagem = mensagem;
            DataCriacao = DateTime.Now;
            Prioridade = prioridade;
            Lida = false;
            DestinatarioId = destinatarioId;
        }

        public string ObterIcone()
        {
            switch (Prioridade)
            {
                case PrioridadeNotificacao.Urgente: return "🔴";
                case PrioridadeNotificacao.Alta: return "🟠";
                case PrioridadeNotificacao.Media: return "🟡";
                default: return "🔵";
            }
        }
    }

    public class SistemaNotificacoes
    {
        private List<Notificacao> notificacoes;
        private GestorEleicoes gestorEleicoes;

        public SistemaNotificacoes(GestorEleicoes gestor)
        {
            notificacoes = new List<Notificacao>();
            gestorEleicoes = gestor;
        }

        public void AdicionarNotificacao(string titulo, string mensagem, PrioridadeNotificacao prioridade, string destinatarioId = null)
        {
            var notificacao = new Notificacao(titulo, mensagem, prioridade, destinatarioId);
            notificacoes.Add(notificacao);
        }

        public void VerificarEleicoesProximas()
        {
            var eleicoesFuturas = gestorEleicoes.ObterEleicoesFuturas();

            foreach (var eleicao in eleicoesFuturas)
            {
                var tempoAteInicio = eleicao.DataInicio - DateTime.Now;

                if (tempoAteInicio.TotalHours <= 24 && tempoAteInicio.TotalHours > 0)
                {
                    AdicionarNotificacao(
                        "⏰ Eleição Próxima!",
                        $"A {eleicao.Nome} começará em {tempoAteInicio.Hours} horas!",
                        PrioridadeNotificacao.Alta
                    );
                }
                else if (tempoAteInicio.TotalHours <= 1 && tempoAteInicio.TotalHours > 0)
                {
                    AdicionarNotificacao(
                        "🚨 ELEIÇÃO IMINENTE!",
                        $"A {eleicao.Nome} começará em menos de 1 hora!",
                        PrioridadeNotificacao.Urgente
                    );
                }
            }
        }

        public void VerificarEleicoesEncerrando()
        {
            var eleicoesAbertas = gestorEleicoes.ObterEleicoesAbertas();

            foreach (var eleicao in eleicoesAbertas)
            {
                var tempoAteFim = eleicao.DataFim - DateTime.Now;

                if (tempoAteFim.TotalHours <= 2 && tempoAteFim.TotalHours > 0)
                {
                    AdicionarNotificacao(
                        "⚠️ Eleição Encerrando!",
                        $"A {eleicao.Nome} encerrará em {tempoAteFim.Hours}h {tempoAteFim.Minutes}m!",
                        PrioridadeNotificacao.Alta
                    );
                }
            }
        }

        public void VerificarQuorumBaixo(EleitoresLista eleitores)
        {
            var eleicoesAbertas = gestorEleicoes.ObterEleicoesAbertas();

            foreach (var eleicao in eleicoesAbertas)
            {
                int totalEleitores = eleitores.ContarTotal();
                int totalVotos = eleicao.Votos.Count;
                double participacao = totalEleitores > 0 ? (totalVotos * 100.0 / totalEleitores) : 0;

                if (participacao < eleicao.QuorumMinimo())
                {
                    AdicionarNotificacao(
                        "📊 Quórum Baixo",
                        $"A {eleicao.Nome} está com {participacao:F1}% de participação (mínimo: {eleicao.QuorumMinimo()}%)",
                        PrioridadeNotificacao.Media
                    );
                }
            }
        }

        public void MostrarNotificacoes(string usuarioId = null)
        {
            var notificacoesParaMostrar = usuarioId == null
                ? notificacoes.Where(n => n.DestinatarioId == null).ToList()
                : notificacoes.Where(n => n.DestinatarioId == usuarioId || n.DestinatarioId == null).ToList();

            var naoLidas = notificacoesParaMostrar.Where(n => !n.Lida).OrderByDescending(n => n.Prioridade).ToList();

            if (naoLidas.Count == 0)
            {
                Console.WriteLine("\n✓ Nenhuma notificação nova.");
                return;
            }

            Console.WriteLine("\n╔════════════════════════════════════════════════════════════╗");
            Console.WriteLine($"║           NOTIFICAÇÕES ({naoLidas.Count} não lidas)                      ║");
            Console.WriteLine("╚════════════════════════════════════════════════════════════╝");

            foreach (var notif in naoLidas)
            {
                Console.WriteLine($"\n{notif.ObterIcone()} {notif.Titulo}");
                Console.WriteLine($"   {notif.Mensagem}");
                Console.WriteLine($"   📅 {notif.DataCriacao:dd/MM/yyyy HH:mm}");
                Console.WriteLine("   ─────────────────────────────────────────");
            }

            Console.Write("\nMarcar todas como lidas? (S/N): ");
            if (Console.ReadLine()?.ToUpper() == "S")
            {
                foreach (var notif in naoLidas)
                {
                    notif.Lida = true;
                }
                Console.WriteLine("✓ Notificações marcadas como lidas.");
            }
        }

        public void MostrarHistoricoNotificacoes()
        {
            Console.WriteLine("\n==========================================");
            Console.WriteLine("      HISTÓRICO DE NOTIFICAÇÕES");
            Console.WriteLine("==========================================");

            if (notificacoes.Count == 0)
            {
                Console.WriteLine("Nenhuma notificação registrada.");
                return;
            }

            foreach (var notif in notificacoes.OrderByDescending(n => n.DataCriacao))
            {
                string status = notif.Lida ? "✓" : "●";
                Console.WriteLine($"\n{status} {notif.ObterIcone()} {notif.Titulo}");
                Console.WriteLine($"   {notif.Mensagem}");
                Console.WriteLine($"   {notif.DataCriacao:dd/MM/yyyy HH:mm} | {notif.Prioridade}");
            }
        }

        public int ContarNaoLidas(string usuarioId = null)
        {
            if (usuarioId == null)
                return notificacoes.Count(n => !n.Lida && n.DestinatarioId == null);

            return notificacoes.Count(n => !n.Lida && (n.DestinatarioId == usuarioId || n.DestinatarioId == null));
        }

        public void LimparNotificacoesAntigas(int diasRetencao = 30)
        {
            var dataLimite = DateTime.Now.AddDays(-diasRetencao);
            int removidas = notificacoes.RemoveAll(n => n.Lida && n.DataCriacao < dataLimite);

            if (removidas > 0)
            {
                Console.WriteLine($"✓ {removidas} notificações antigas removidas.");
            }
        }

        public void NotificarNovoVoto(string eleicaoNome, string candidatoNome)
        {
            AdicionarNotificacao(
                "🗳️ Novo Voto",
                $"Voto registrado na {eleicaoNome} para {candidatoNome}",
                PrioridadeNotificacao.Baixa
            );
        }

        public void NotificarEleicaoAberta(string eleicaoNome)
        {
            AdicionarNotificacao(
                "🟢 Eleição Aberta",
                $"A {eleicaoNome} está agora aberta para votação!",
                PrioridadeNotificacao.Alta
            );
        }

        public void NotificarEleicaoEncerrada(string eleicaoNome)
        {
            AdicionarNotificacao(
                "🔴 Eleição Encerrada",
                $"A {eleicaoNome} foi encerrada. Confira os resultados!",
                PrioridadeNotificacao.Media
            );
        }

        public void VerificarTodasAlertas(EleitoresLista eleitores)
        {
            VerificarEleicoesProximas();
            VerificarEleicoesEncerrando();
            VerificarQuorumBaixo(eleitores);
        }
    }
}