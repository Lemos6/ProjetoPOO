﻿using System;
using System.IO;
using System.Text;
using System.Linq;

namespace ProjetoPOO
{
    public class PersistenciaDados
    {
        private const string ArquivoDados = "sistema_votacao.dat";
        private const string Separador = "|";

        public void SalvarTudo(EleitoresLista eleitores, CandidatosLista candidatos, GestorEleicoes gestor)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(ArquivoDados, false, Encoding.UTF8))
                {
                    // === ELEITORES ===
                    writer.WriteLine("[ELEITORES_INICIO]");
                    foreach (var eleitor in eleitores.ObterTodos())
                    {
                        writer.WriteLine($"{eleitor.Id}{Separador}{eleitor.Nome}{Separador}{eleitor.Idade}{Separador}{eleitor.JaVotou}");
                    }
                    writer.WriteLine("[ELEITORES_FIM]");

                    // === CANDIDATOS ===
                    writer.WriteLine("[CANDIDATOS_INICIO]");
                    foreach (var candidato in candidatos.ObterCandidatos())
                    {
                        writer.WriteLine($"{candidato.Id}{Separador}{candidato.Nome}{Separador}{candidato.Idade}");
                    }
                    writer.WriteLine("[CANDIDATOS_FIM]");

                    // === ELEIÇÕES ===
                    writer.WriteLine("[ELEICOES_INICIO]");
                    var todasEleicoes = gestor.ObterEleicoesAbertas()
                        .Concat(gestor.ObterEleicoesFuturas())
                        .Concat(gestor.ObterEleicoesEncerradas());

                    foreach (var eleicao in todasEleicoes)
                    {
                        writer.WriteLine("[ELEICAO]");
                        writer.WriteLine($"TIPO{Separador}{(int)eleicao.Tipo}");
                        writer.WriteLine($"NOME{Separador}{eleicao.Nome}");
                        writer.WriteLine($"INICIO{Separador}{eleicao.DataInicio:yyyy-MM-dd HH:mm:ss}");
                        writer.WriteLine($"FIM{Separador}{eleicao.DataFim:yyyy-MM-dd HH:mm:ss}");

                        // Candidatos da eleição
                        writer.WriteLine("[CANDIDATOS_ELEICAO]");
                        foreach (var candidato in eleicao.Candidatos)
                        {
                            writer.WriteLine($"{candidato.Id}");
                        }
                        writer.WriteLine("[CANDIDATOS_ELEICAO_FIM]");

                        // Votos da eleição
                        writer.WriteLine("[VOTOS]");
                        foreach (var voto in eleicao.Votos)
                        {
                            writer.WriteLine($"{voto.IdCandidato}{Separador}{voto.IdEleitor}{Separador}{voto.DataVoto:yyyy-MM-dd HH:mm:ss}");
                        }
                        writer.WriteLine("[VOTOS_FIM]");
                        writer.WriteLine("[ELEICAO_FIM]");
                    }
                    writer.WriteLine("[ELEICOES_FIM]");
                }

                Console.WriteLine($"✓ Dados salvos em {ArquivoDados}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Erro ao salvar dados: {ex.Message}");
            }
        }

        public void CarregarTudo(EleitoresLista eleitores, CandidatosLista candidatos, GestorEleicoes gestor)
        {
            if (!File.Exists(ArquivoDados))
            {
                Console.WriteLine("ℹ️  Nenhum arquivo de dados encontrado. Usando dados padrão.");
                return;
            }

            try
            {
                using (StreamReader reader = new StreamReader(ArquivoDados, Encoding.UTF8))
                {
                    string linha;
                    string secao = "";

                    while ((linha = reader.ReadLine()) != null)
                    {
                        // Identificar seções
                        if (linha == "[ELEITORES_INICIO]")
                        {
                            secao = "ELEITORES";
                            continue;
                        }
                        else if (linha == "[ELEITORES_FIM]")
                        {
                            secao = "";
                            continue;
                        }
                        else if (linha == "[CANDIDATOS_INICIO]")
                        {
                            secao = "CANDIDATOS";
                            continue;
                        }
                        else if (linha == "[CANDIDATOS_FIM]")
                        {
                            secao = "";
                            continue;
                        }
                        else if (linha == "[ELEICOES_INICIO]")
                        {
                            secao = "ELEICOES";
                            continue;
                        }
                        else if (linha == "[ELEICAO]")
                        {
                            // Nova eleição será criada
                            continue;
                        }
                        else if (linha == "[ELEICAO_FIM]")
                        {
                            continue;
                        }

                        // Processar dados
                        if (secao == "ELEITORES" && linha.Contains(Separador))
                        {
                            var partes = linha.Split(new[] { Separador }, StringSplitOptions.None);
                            if (partes.Length >= 4)
                            {
                                var eleitor = new Eleitor
                                {
                                    Id = partes[0],
                                    Nome = partes[1],
                                    Idade = int.Parse(partes[2]),
                                    JaVotou = bool.Parse(partes[3])
                                };

                                // Só adiciona se não existir
                                if (eleitores.ObterPorId(eleitor.Id) == null)
                                {
                                    eleitores.AdicionarEleitor(eleitor);
                                }
                            }
                        }
                        else if (secao == "CANDIDATOS" && linha.Contains(Separador))
                        {
                            var partes = linha.Split(new[] { Separador }, StringSplitOptions.None);
                            if (partes.Length >= 3)
                            {
                                var candidato = new Candidato
                                {
                                    Id = int.Parse(partes[0]),
                                    Nome = partes[1],
                                    Idade = int.Parse(partes[2])
                                };

                                // Só adiciona se não existir
                                if (candidatos.ObterPorId(candidato.Id) == null)
                                {
                                    candidatos.AdicionarCandidato(candidato);
                                }
                            }
                        }
                        else if (secao == "ELEICOES" && linha.StartsWith("TIPO"))
                        {
                            // Processar dados da eleição será feito em uma versão futura
                            // Para simplificar, vamos pular por agora
                        }
                    }
                }

                Console.WriteLine($"✓ Dados carregados de {ArquivoDados}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Erro ao carregar dados: {ex.Message}");
                Console.WriteLine("   Usando dados padrão.");
            }
        }

        public bool ExisteDadosSalvos()
        {
            return File.Exists(ArquivoDados);
        }

        public void LimparDados()
        {
            try
            {
                if (File.Exists(ArquivoDados))
                {
                    File.Delete(ArquivoDados);
                    Console.WriteLine("✓ Dados limpos com sucesso!");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Erro ao limpar dados: {ex.Message}");
            }
        }
    }
}