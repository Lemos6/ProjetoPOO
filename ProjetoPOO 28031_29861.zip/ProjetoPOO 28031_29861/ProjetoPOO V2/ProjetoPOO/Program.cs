using System;

namespace ProjetoPOO
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            var persistencia = new PersistenciaDados();
            var listaCandidatos = new CandidatosLista();
            var listaEleitores = new EleitoresLista();
            var gestorEleicoes = new GestorEleicoes();
            var sistemaVotacao = new SistemaVotacaoV2(listaCandidatos, listaEleitores, gestorEleicoes);
            var autenticacao = new Autenticacao();
            var auditoria = new Auditoria();
            var relatorio = new RelatorioEleicao();
            var notificacoes = new SistemaNotificacoes(gestorEleicoes);
            var estatisticas = new EstatisticasAvancadas();

            // Carregar dados salvos se existirem
            if (persistencia.ExisteDadosSalvos())
            {
                Console.WriteLine("ℹ️  Carregando dados salvos...");
                persistencia.CarregarTudo(listaEleitores, listaCandidatos, gestorEleicoes);
            }

            bool sistemaAtivo = true;
            string usuarioAutenticado = null;

            while (sistemaAtivo)
            {
                if (usuarioAutenticado == null)
                {
                    MenuPrincipal(
                        ref sistemaAtivo,
                        ref usuarioAutenticado,
                        autenticacao,
                        auditoria,
                        listaEleitores,
                        listaCandidatos,
                        gestorEleicoes,
                        sistemaVotacao,
                        persistencia,
                        notificacoes,
                        relatorio);
                }
                else
                {
                    MenuAutenticado(
                        ref usuarioAutenticado,
                        listaCandidatos,
                        listaEleitores,
                        gestorEleicoes,
                        sistemaVotacao,
                        autenticacao,
                        auditoria,
                        relatorio,
                        notificacoes,
                        estatisticas,
                        persistencia);
                }
            }

            // Salvar dados ao sair
            Console.WriteLine("ℹ️  Salvando dados...");
            persistencia.SalvarTudo(listaEleitores, listaCandidatos, gestorEleicoes);
            Console.WriteLine("✓ Dados salvos! Até breve!");
        }

        static void MenuPrincipal(
            ref bool sistemaAtivo,
            ref string usuarioAutenticado,
            Autenticacao autenticacao,
            Auditoria auditoria,
            EleitoresLista eleitores,
            CandidatosLista candidatos,
            GestorEleicoes gestor,
            SistemaVotacaoV2 sistema,
            PersistenciaDados persistencia,
            SistemaNotificacoes notificacoes,
            RelatorioEleicao relatorio)
        {
            Console.Clear();
            Console.WriteLine("\n╔════════════════════════════════════════════════════════════╗");
            Console.WriteLine("║          SISTEMA DE VOTAÇÃO ELETRÓNICA                    ║");
            Console.WriteLine("╚════════════════════════════════════════════════════════════╝");

            Console.WriteLine("\n  1. Login de Eleitor");
            Console.WriteLine("  2. Registrar Novo Eleitor");
            Console.WriteLine("  3. Ver Eleições Disponíveis");
            Console.WriteLine("  0. Sair");

            Console.Write("\nOpção: ");
            var escolha = Console.ReadLine();

            switch (escolha)
            {
                case "1":
                    Console.Write("\nID do eleitor: ");
                    string id = Console.ReadLine();
                    Console.Write("Senha: ");
                    string senha = Console.ReadLine();

                    if (autenticacao.Autenticar(id, senha))
                    {
                        usuarioAutenticado = id;
                        auditoria.RegistrarEvento(TipoEvento.Login, usuarioAutenticado, "Login realizado");
                        notificacoes.VerificarTodasAlertas(eleitores);
                    }
                    break;

                case "2":
                    RegistrarNovoEleitor(autenticacao);
                    break;

                case "3":
                    gestor.ListarEleicoes();
                    break;

                case "0":
                    Console.Write("\nDeseja realmente sair? (S/N): ");
                    if (Console.ReadLine()?.ToUpper() == "S")
                    {
                        sistemaAtivo = false;
                    }
                    break;

                default:
                    Console.WriteLine("❌ Opção inválida!");
                    break;
            }

            if (sistemaAtivo && usuarioAutenticado == null)
            {
                Console.WriteLine("\nPressione qualquer tecla para continuar...");
                Console.ReadKey();
            }
        }

        static void MenuAutenticado(
            ref string usuarioAutenticado,
            CandidatosLista listaCandidatos,
            EleitoresLista listaEleitores,
            GestorEleicoes gestorEleicoes,
            SistemaVotacaoV2 sistemaVotacao,
            Autenticacao autenticacao,
            Auditoria auditoria,
            RelatorioEleicao relatorio,
            SistemaNotificacoes notificacoes,
            EstatisticasAvancadas estatisticas,
            PersistenciaDados persistencia)
        {
            Console.Clear();
            int naoLidas = notificacoes.ContarNaoLidas(usuarioAutenticado);

            Console.WriteLine($"\n╔════════════════════════════════════════════════════════════╗");
            Console.WriteLine($"║  Bem-vindo, {usuarioAutenticado,-46} ║");
            Console.WriteLine($"╚════════════════════════════════════════════════════════════╝");

            if (naoLidas > 0)
            {
                Console.WriteLine($"\n🔔 Você tem {naoLidas} notificações não lidas!");
            }

            Console.WriteLine("\n📋 CONSULTAS");
            Console.WriteLine("  1. Listar Candidatos");
            Console.WriteLine("  2. Listar Eleitores");
            Console.WriteLine("  3. Listar Eleições");

            Console.WriteLine("\n🗳️  VOTAÇÃO");
            Console.WriteLine("  4. Votar");
            Console.WriteLine("  5. Ver Meu Histórico de Votos");

            Console.WriteLine("\n⚙️  GESTÃO DE ELEIÇÕES");
            Console.WriteLine("  6. Criar Nova Eleição");
            Console.WriteLine("  7. Adicionar Candidato a Eleição");

            Console.WriteLine("\n📊 RELATÓRIOS");
            Console.WriteLine("  8. Dashboard Geral");
            Console.WriteLine("  9. Relatório de Eleição Específica");
            Console.WriteLine("  10. Análise por Faixa Etária");

            Console.WriteLine("\n🔔 SISTEMA");
            Console.WriteLine($"  11. Ver Notificações ({naoLidas})");
            Console.WriteLine("  12. Histórico de Auditoria");
            Console.WriteLine("  13. Criar Backup");

            Console.WriteLine("\n🔐 CONTA");
            Console.WriteLine("  14. Alterar Senha");
            Console.WriteLine("  0. Logout");

            Console.Write("\nOpção: ");
            var escolha = Console.ReadLine();

            try
            {
                switch (escolha)
                {
                    case "1":
                        ListarCandidatosDetalhado(listaCandidatos);
                        break;
                    case "2":
                        ListarEleitores(listaEleitores);
                        break;
                    case "3":
                        gestorEleicoes.ListarEleicoes();
                        break;
                    case "4":
                        sistemaVotacao.ProcessarVotacao();
                        auditoria.RegistrarEvento(TipoEvento.VotoRegistrado, usuarioAutenticado, "Voto processado");
                        break;
                    case "5":
                        sistemaVotacao.MostrarHistoricoVotos(usuarioAutenticado);
                        break;
                    case "6":
                        gestorEleicoes.CriarNovaEleicao();
                        auditoria.RegistrarEvento(TipoEvento.EleicaoCriada, usuarioAutenticado, "Nova eleição criada");
                        break;
                    case "7":
                        gestorEleicoes.AdicionarCandidatoAEleicao(listaCandidatos);
                        break;
                    case "8":
                        estatisticas.GerarDashboard(gestorEleicoes, listaEleitores, listaCandidatos);
                        break;
                    case "9":
                        RelatorioEleicaoEspecifica(gestorEleicoes, listaEleitores);
                        break;
                    case "10":
                        estatisticas.AnalisarPorIdade(listaEleitores);
                        break;
                    case "11":
                        notificacoes.MostrarNotificacoes(usuarioAutenticado);
                        break;
                    case "12":
                        auditoria.ExibirHistorico();
                        break;
                    case "13":
                        persistencia.SalvarTudo(listaEleitores, listaCandidatos, gestorEleicoes);
                        break;
                    case "14":
                        AlterarSenhaInterativo(usuarioAutenticado, autenticacao, auditoria);
                        break;
                    case "0":
                        autenticacao.Logout(usuarioAutenticado);
                        auditoria.RegistrarEvento(TipoEvento.Logout, usuarioAutenticado, "Logout realizado");
                        usuarioAutenticado = null;
                        Console.WriteLine("✓ Logout realizado com sucesso!");
                        break;
                    default:
                        Console.WriteLine("❌ Opção inválida!");
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"\n❌ Erro: {ex.Message}");
            }

            if (usuarioAutenticado != null)
            {
                Console.WriteLine("\nPressione qualquer tecla para continuar...");
                Console.ReadKey();
            }
        }

        static void ListarCandidatosDetalhado(CandidatosLista lista)
        {
            Console.WriteLine("\n==========================================");
            Console.WriteLine("         LISTA COMPLETA DE CANDIDATOS");
            Console.WriteLine("==========================================");

            var candidatos = lista.ObterCandidatos();

            if (candidatos.Count == 0)
            {
                Console.WriteLine("Nenhum candidato registrado.");
                return;
            }

            foreach (var c in candidatos)
            {
                Console.WriteLine($"\nID: {c.Id}");
                Console.WriteLine($"Nome: {c.Nome}");
                Console.WriteLine($"Idade: {c.Idade} anos");
                Console.WriteLine($"Elegível: {(c.ElegivelParaCandidatar() ? "✓ Sim" : "✗ Não (idade < 35)")}");
                Console.WriteLine("------------------------------------------");
            }

            Console.WriteLine($"\n📊 Total: {candidatos.Count} | Elegíveis: {lista.ContarElegiveis()}");
        }

        static void ListarEleitores(EleitoresLista lista)
        {
            Console.WriteLine("\n==========================================");
            Console.WriteLine("         LISTA COMPLETA DE ELEITORES");
            Console.WriteLine("==========================================");

            var eleitores = lista.ObterTodos();

            if (eleitores.Count == 0)
            {
                Console.WriteLine("Nenhum eleitor registrado.");
                return;
            }

            foreach (var e in eleitores)
            {
                Console.WriteLine($"\nID: {e.Id}");
                Console.WriteLine($"Nome: {e.Nome}");
                Console.WriteLine($"Idade: {e.Idade} anos");
                Console.WriteLine($"Pode votar: {(e.PodeVotar ? "✓ Sim" : "✗ Não")}");
                Console.WriteLine($"Status: {(e.JaVotou ? "Já votou" : "Disponível")}");
                Console.WriteLine("------------------------------------------");
            }

            Console.WriteLine($"\n📊 Total: {eleitores.Count} | Elegíveis: {lista.ContarElegiveis()} | Votaram: {lista.ContarQueVotaram()}");
        }

        static void RelatorioEleicaoEspecifica(GestorEleicoes gestor, EleitoresLista eleitores)
        {
            var eleicao = gestor.SelecionarEleicao();
            if (eleicao != null)
            {
                gestor.GerarRelatorioEleicao(eleicao, eleitores);
            }
        }

        static void RegistrarNovoEleitor(Autenticacao autenticacao)
        {
            Console.WriteLine("\n--- Registrar Novo Eleitor ---");
            Console.Write("ID do eleitor: ");
            string id = Console.ReadLine();
            Console.Write("Senha (mínimo 4 caracteres): ");
            string senha = Console.ReadLine();

            autenticacao.RegistrarCredencial(id, senha);
        }

        static void AlterarSenhaInterativo(string usuarioId, Autenticacao autenticacao, Auditoria auditoria)
        {
            Console.WriteLine("\n--- Alterar Senha ---");
            Console.Write("Senha atual: ");
            string senhaAtual = Console.ReadLine();
            Console.Write("Nova senha: ");
            string novaSenha = Console.ReadLine();

            autenticacao.AlterarSenha(usuarioId, senhaAtual, novaSenha);
            auditoria.RegistrarEvento(TipoEvento.AlteracaoSenha, usuarioId, "Senha alterada");
        }
    }
}