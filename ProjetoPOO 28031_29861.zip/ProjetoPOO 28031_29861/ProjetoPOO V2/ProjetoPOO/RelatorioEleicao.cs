﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ProjetoPOO
{
    public class RelatorioEleicao
    {
        public void GerarRelatorioCompleto(
            CandidatosLista candidatos,
            EleitoresLista eleitores,
            Dictionary<int, int> resultados)
        {
            Console.WriteLine("\n================================================");
            Console.WriteLine("         RELATÓRIO COMPLETO DA ELEIÇÃO");
            Console.WriteLine("================================================");

            GerarEstatisticasParticipacao(eleitores);
            GerarResultadosPorCandidato(candidatos, resultados, eleitores.ContarQueVotaram());
            GerarAnaliseElegibilidade(candidatos, eleitores);
            DetectarAnomalias(resultados, eleitores);
        }

        private void GerarEstatisticasParticipacao(EleitoresLista eleitores)
        {
            Console.WriteLine("\n--- PARTICIPAÇÃO ---");

            int total = eleitores.ContarTotal();
            int votaram = eleitores.ContarQueVotaram();
            int elegiveis = eleitores.ContarElegiveis();

            double taxaParticipacao = total > 0 ? (votaram * 100.0 / total) : 0;
            double taxaElegiveisVotaram = elegiveis > 0 ? (votaram * 100.0 / elegiveis) : 0;

            Console.WriteLine($"Total de eleitores registrados: {total}");
            Console.WriteLine($"Eleitores elegíveis: {elegiveis}");
            Console.WriteLine($"Eleitores que votaram: {votaram}");
            Console.WriteLine($"Taxa de participação geral: {taxaParticipacao:F2}%");
            Console.WriteLine($"Taxa entre elegíveis: {taxaElegiveisVotaram:F2}%");
        }

        private void GerarResultadosPorCandidato(
            CandidatosLista candidatos,
            Dictionary<int, int> resultados,
            int totalVotos)
        {
            Console.WriteLine("\n--- RESULTADOS POR CANDIDATO ---");

            if (resultados.Count == 0)
            {
                Console.WriteLine("Nenhum voto registrado.");
                return;
            }

            var resultadosOrdenados = resultados
                .OrderByDescending(r => r.Value)
                .ToList();

            int posicao = 1;
            foreach (var resultado in resultadosOrdenados)
            {
                var candidato = candidatos.ObterPorId(resultado.Key);
                if (candidato != null)
                {
                    double percentual = totalVotos > 0 ? (resultado.Value * 100.0 / totalVotos) : 0;
                    string barraProgresso = GerarBarraProgresso(percentual);

                    Console.WriteLine($"\n{posicao}º lugar: {candidato.Nome}");
                    Console.WriteLine($"   Votos: {resultado.Value} ({percentual:F2}%)");
                    Console.WriteLine($"   {barraProgresso}");
                    posicao++;
                }
            }

            // Vencedor
            if (resultadosOrdenados.Count > 0)
            {
                var vencedorId = resultadosOrdenados[0].Key;
                var vencedor = candidatos.ObterPorId(vencedorId);
                Console.WriteLine($"\n🏆 VENCEDOR: {vencedor.Nome} com {resultadosOrdenados[0].Value} votos!");
            }
        }

        private void GerarAnaliseElegibilidade(CandidatosLista candidatos, EleitoresLista eleitores)
        {
            Console.WriteLine("\n--- ANÁLISE DE ELEGIBILIDADE ---");

            var todosCandidatos = candidatos.ObterCandidatos();
            int candidatosElegiveis = candidatos.ContarElegiveis();
            int candidatosNaoElegiveis = todosCandidatos.Count - candidatosElegiveis;

            Console.WriteLine($"Candidatos elegíveis: {candidatosElegiveis}");
            Console.WriteLine($"Candidatos não elegíveis: {candidatosNaoElegiveis}");

            if (candidatosNaoElegiveis > 0)
            {
                Console.WriteLine("\nCandidatos não elegíveis (idade < 35):");
                foreach (var c in todosCandidatos.Where(c => !c.ElegivelParaCandidatar()))
                {
                    Console.WriteLine($"  - {c.Nome} ({c.Idade} anos)");
                }
            }

            var todosEleitores = eleitores.ObterTodos();
            int eleitoresNaoElegiveis = todosEleitores.Count(e => !e.PodeVotar);

            Console.WriteLine($"\nEleitores não elegíveis (idade < 18): {eleitoresNaoElegiveis}");
            if (eleitoresNaoElegiveis > 0)
            {
                Console.WriteLine("Lista:");
                foreach (var e in todosEleitores.Where(e => !e.PodeVotar))
                {
                    Console.WriteLine($"  - {e.Nome} ({e.Idade} anos)");
                }
            }
        }

        private void DetectarAnomalias(Dictionary<int, int> resultados, EleitoresLista eleitores)
        {
            Console.WriteLine("\n--- DETECÇÃO DE ANOMALIAS ---");

            bool anomaliaDetectada = false;

            // Verificar se há votos duplicados (mais votos que eleitores)
            int totalVotos = resultados.Values.Sum();
            int totalEleitores = eleitores.ContarQueVotaram();

            if (totalVotos > totalEleitores)
            {
                Console.WriteLine($"⚠️ ALERTA: Número de votos ({totalVotos}) excede número de eleitores que votaram ({totalEleitores})!");
                anomaliaDetectada = true;
            }

            // Verificar concentração anormal de votos
            if (resultados.Count > 0)
            {
                int maxVotos = resultados.Values.Max();
                double concentracao = totalVotos > 0 ? (maxVotos * 100.0 / totalVotos) : 0;

                if (concentracao > 80 && resultados.Count > 1)
                {
                    Console.WriteLine($"⚠️ ALERTA: Concentração anormal de votos ({concentracao:F1}%) em um único candidato!");
                    anomaliaDetectada = true;
                }
            }

            if (!anomaliaDetectada)
            {
                Console.WriteLine("✓ Nenhuma anomalia detectada.");
            }
        }

        private string GerarBarraProgresso(double percentual)
        {
            int tamanho = 30;
            int preenchido = (int)(tamanho * percentual / 100);
            string barra = new string('█', preenchido) + new string('░', tamanho - preenchido);
            return $"[{barra}]";
        }

        public void GerarRelatorioSimples(Dictionary<int, int> resultados, CandidatosLista candidatos)
        {
            Console.WriteLine("\n--- RESULTADOS ---");

            if (resultados.Count == 0)
            {
                Console.WriteLine("Nenhum voto registrado.");
                return;
            }

            var ordenados = resultados.OrderByDescending(r => r.Value);
            int totalVotos = resultados.Values.Sum();

            foreach (var resultado in ordenados)
            {
                var candidato = candidatos.ObterPorId(resultado.Key);
                if (candidato != null)
                {
                    double percentual = totalVotos > 0 ? (resultado.Value * 100.0 / totalVotos) : 0;
                    Console.WriteLine($"{candidato.Nome}: {resultado.Value} votos ({percentual:F1}%)");
                }
            }
        }
    }
}