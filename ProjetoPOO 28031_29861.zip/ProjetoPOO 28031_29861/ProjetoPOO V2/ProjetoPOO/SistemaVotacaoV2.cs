﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ProjetoPOO
{
    public class SistemaVotacaoV2
    {
        private readonly CandidatosLista candidatos;
        private readonly EleitoresLista eleitores;
        private readonly GestorEleicoes gestorEleicoes;
        private Dictionary<string, HashSet<TipoEleicao>> votosRegistrados;

        public SistemaVotacaoV2(CandidatosLista candidatos, EleitoresLista eleitores, GestorEleicoes gestorEleicoes)
        {
            this.candidatos = candidatos ?? throw new ArgumentNullException(nameof(candidatos));
            this.eleitores = eleitores ?? throw new ArgumentNullException(nameof(eleitores));
            this.gestorEleicoes = gestorEleicoes ?? throw new ArgumentNullException(nameof(gestorEleicoes));
            this.votosRegistrados = new Dictionary<string, HashSet<TipoEleicao>>();
        }

        public void ProcessarVotacao()
        {
            Console.WriteLine("==========================================");
            Console.WriteLine("            PROCESSO DE VOTAÇÃO");
            Console.WriteLine("==========================================");

            try
            {
                // Passo 1: Selecionar eleição
                var eleicao = gestorEleicoes.SelecionarEleicao();
                if (eleicao == null) return;

                // Verificar se há candidatos nesta eleição
                if (eleicao.Candidatos.Count == 0)
                {
                    Console.WriteLine("\n❌ Esta eleição não tem candidatos registrados ainda.");
                    return;
                }

                // Passo 2: Identificar o eleitor
                var eleitor = IdentificarEleitor();
                if (eleitor == null) return;

                // Passo 3: Verificar se já votou NESTA eleição específica
                if (JaVotouNestaEleicao(eleitor.Id, eleicao.Tipo))
                {
                    Console.WriteLine($"\n❌ {eleitor.Nome} já votou na {eleicao.Nome}!");
                    return;
                }

                // Passo 4: Verificar elegibilidade geral
                if (!VerificarElegibilidade(eleitor)) return;

                // Passo 5: Mostrar candidatos desta eleição
                MostrarCandidatos(eleicao);

                // Passo 6: Registrar voto
                RegistrarVoto(eleitor, eleicao);
            }
            catch (VotacaoEncerradaException ex)
            {
                Console.WriteLine($"\n❌ {ex.Message}");
            }
            catch (EleitorJaVotouException ex)
            {
                Console.WriteLine($"\n❌ {ex.Message}");
            }
            catch (EleitorNaoElegivelException ex)
            {
                Console.WriteLine($"\n❌ {ex.Message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"\n❌ Erro durante a votação: {ex.Message}");
            }
        }

        private Eleitor IdentificarEleitor()
        {
            Console.Write("\nDigite o ID do eleitor (ex: E001): ");
            string eleitorId = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(eleitorId))
            {
                Console.WriteLine("❌ ID não pode estar vazio!");
                return null;
            }

            var eleitor = eleitores.ObterPorId(eleitorId);

            if (eleitor == null)
            {
                Console.WriteLine("❌ Eleitor não encontrado!");
                return null;
            }

            Console.WriteLine($"\n--- Dados do Eleitor ---");
            Console.WriteLine($"Nome: {eleitor.Nome}");
            Console.WriteLine($"Idade: {eleitor.Idade} anos");
            Console.WriteLine($"ID: {eleitor.Id}");

            return eleitor;
        }

        private bool VerificarElegibilidade(Eleitor eleitor)
        {
            if (!eleitor.PodeVotar)
            {
                Console.WriteLine($"\n❌ {eleitor.Nome} não pode votar!");
                Console.WriteLine("   Motivo: Menor de 18 anos.");
                return false;
            }

            return true;
        }

        private void MostrarCandidatos(Eleicao eleicao)
        {
            Console.WriteLine("\n------------------------------------------");
            Console.WriteLine($"Candidatos da {eleicao.Nome}:");
            Console.WriteLine("------------------------------------------");

            var resultados = eleicao.ObterResultados();

            foreach (var candidato in eleicao.Candidatos)
            {
                int votosAtuais = resultados.ContainsKey(candidato.Id) ? resultados[candidato.Id] : 0;
                Console.WriteLine($"ID: {candidato.Id} - {candidato.Nome} ({candidato.Idade} anos) - Votos: {votosAtuais}");
            }
        }

        private void RegistrarVoto(Eleitor eleitor, Eleicao eleicao)
        {
            Console.Write("\nDigite o ID do candidato em quem deseja votar: ");
            if (!int.TryParse(Console.ReadLine(), out int candidatoId))
            {
                Console.WriteLine("❌ ID inválido!");
                return;
            }

            var candidatoEscolhido = eleicao.Candidatos.FirstOrDefault(c => c.Id == candidatoId);

            if (candidatoEscolhido == null)
            {
                Console.WriteLine("❌ Candidato não encontrado nesta eleição!");
                return;
            }

            // Criar um eleitor temporário para não alterar o estado do original
            var eleitorTemp = new Eleitor
            {
                Id = eleitor.Id,
                Nome = eleitor.Nome,
                Idade = eleitor.Idade,
                JaVotou = false
            };

            // Registrar o voto na eleição
            eleicao.RegistarVoto(candidatoEscolhido, eleitorTemp);

            // Marcar que votou nesta eleição específica
            RegistrarVotoPorTipoEleicao(eleitor.Id, eleicao.Tipo);

            Console.WriteLine($"\n✓ Voto registrado com sucesso!");
            Console.WriteLine($"  Eleitor: {eleitor.Nome}");
            Console.WriteLine($"  Eleição: {eleicao.Nome}");
            Console.WriteLine($"  Votou em: {candidatoEscolhido.Nome}");

            // Mostrar estatísticas desta eleição
            MostrarEstatisticasEleicao(eleicao);
        }

        private bool JaVotouNestaEleicao(string eleitorId, TipoEleicao tipo)
        {
            if (!votosRegistrados.ContainsKey(eleitorId))
                return false;

            return votosRegistrados[eleitorId].Contains(tipo);
        }

        private void RegistrarVotoPorTipoEleicao(string eleitorId, TipoEleicao tipo)
        {
            if (!votosRegistrados.ContainsKey(eleitorId))
            {
                votosRegistrados[eleitorId] = new HashSet<TipoEleicao>();
            }

            votosRegistrados[eleitorId].Add(tipo);
        }

        private void MostrarEstatisticasEleicao(Eleicao eleicao)
        {
            Console.WriteLine("\n------------------------------------------");
            Console.WriteLine($"Estatísticas da {eleicao.Nome}:");
            Console.WriteLine("------------------------------------------");

            var resultados = eleicao.ObterResultados();
            int totalVotos = resultados.Values.Sum();

            Console.WriteLine($"Total de votos: {totalVotos}");
            Console.WriteLine($"Candidatos: {eleicao.Candidatos.Count}");

            if (resultados.Count > 0)
            {
                var ordenados = resultados.OrderByDescending(r => r.Value).Take(3);
                Console.WriteLine("\nTop 3 candidatos:");

                int pos = 1;
                foreach (var resultado in ordenados)
                {
                    var candidato = eleicao.Candidatos.FirstOrDefault(c => c.Id == resultado.Key);
                    if (candidato != null)
                    {
                        double percentual = totalVotos > 0 ? (resultado.Value * 100.0 / totalVotos) : 0;
                        Console.WriteLine($"  {pos}º {candidato.Nome}: {resultado.Value} ({percentual:F1}%)");
                        pos++;
                    }
                }
            }
        }

        public void MostrarHistoricoVotos(string eleitorId)
        {
            var eleitor = eleitores.ObterPorId(eleitorId);
            if (eleitor == null)
            {
                Console.WriteLine("❌ Eleitor não encontrado!");
                return;
            }

            Console.WriteLine($"\n--- Histórico de Votos: {eleitor.Nome} ---");

            if (!votosRegistrados.ContainsKey(eleitorId) || votosRegistrados[eleitorId].Count == 0)
            {
                Console.WriteLine("Nenhum voto registrado.");
                return;
            }

            Console.WriteLine("Eleições em que votou:");
            foreach (var tipo in votosRegistrados[eleitorId])
            {
                Console.WriteLine($"  ✓ {tipo}");
            }
        }

        public Dictionary<int, int> ObterResultados()
        {
            var resultadosGlobais = new Dictionary<int, int>();

            var todasEleicoes = gestorEleicoes.ObterEleicoesAbertas()
                .Concat(gestorEleicoes.ObterEleicoesEncerradas());

            foreach (var eleicao in todasEleicoes)
            {
                var resultadosEleicao = eleicao.ObterResultados();
                foreach (var resultado in resultadosEleicao)
                {
                    if (!resultadosGlobais.ContainsKey(resultado.Key))
                    {
                        resultadosGlobais[resultado.Key] = 0;
                    }
                    resultadosGlobais[resultado.Key] += resultado.Value;
                }
            }

            return resultadosGlobais;
        }

        public void ReiniciarVotacao()
        {
            votosRegistrados.Clear();
            Console.WriteLine("✓ Sistema de votação reiniciado!");
        }
    }
}