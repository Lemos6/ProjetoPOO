﻿namespace ProjetoPOO
{
    public enum TipoEleicao
    {
        Presidencial = 1,
        Assembleia = 2,
        Municipal = 3
    }
}