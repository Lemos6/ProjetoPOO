﻿using System;

namespace ProjetoPOO
{
    public class Voto
    {
        public Guid IdVoto { get; private set; }
        public int IdCandidato { get; private set; }
        public string IdEleitor { get; private set; }
        public DateTime DataVoto { get; private set; }
        public TipoEleicao TipoEleicao { get; private set; }

        public Voto(int idCandidato, string idEleitor, TipoEleicao tipoEleicao)
        {
            if (idCandidato <= 0)
                throw new ArgumentException("ID do candidato inválido.");
            if (string.IsNullOrWhiteSpace(idEleitor))
                throw new ArgumentException("ID do eleitor inválido.");

            IdVoto = Guid.NewGuid();
            IdCandidato = idCandidato;
            IdEleitor = idEleitor;
            DataVoto = DateTime.Now;
            TipoEleicao = tipoEleicao;
        }

        public override string ToString()
        {
            return $"Voto {IdVoto} - Candidato: {IdCandidato}, Eleitor: {IdEleitor}, Data: {DataVoto:dd/MM/yyyy HH:mm}";
        }
    }
}