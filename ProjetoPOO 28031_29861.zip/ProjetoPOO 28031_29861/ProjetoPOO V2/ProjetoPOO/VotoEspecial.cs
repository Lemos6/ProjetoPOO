﻿using System;

namespace ProjetoPOO
{
    public enum TipoVotoEspecial
    {
        Normal = 0,
        Branco = -1,
        Nulo = -2
    }

    public class VotoEspecial : Voto
    {
        public TipoVotoEspecial TipoEspecial { get; private set; }

        // Construtor para voto normal
        public VotoEspecial(int idCandidato, string idEleitor, TipoEleicao tipoEleicao)
            : base(idCandidato, idEleitor, tipoEleicao)
        {
            TipoEspecial = TipoVotoEspecial.Normal;
        }

        // Construtor para voto especial (branco/nulo)
        public VotoEspecial(TipoVotoEspecial tipoEspecial, string idEleitor, TipoEleicao tipoEleicao)
            : base((int)tipoEspecial, idEleitor, tipoEleicao)
        {
            if (tipoEspecial == TipoVotoEspecial.Normal)
                throw new ArgumentException("Use o construtor com ID do candidato para votos normais.");

            TipoEspecial = tipoEspecial;
        }

        public bool EhVotoBranco() => TipoEspecial == TipoVotoEspecial.Branco;
        public bool EhVotoNulo() => TipoEspecial == TipoVotoEspecial.Nulo;
        public bool EhVotoNormal() => TipoEspecial == TipoVotoEspecial.Normal;

        public override string ToString()
        {
            if (EhVotoBranco())
                return $"Voto {IdVoto} - BRANCO - Eleitor: {IdEleitor}, Data: {DataVoto:dd/MM/yyyy HH:mm}";
            else if (EhVotoNulo())
                return $"Voto {IdVoto} - NULO - Eleitor: {IdEleitor}, Data: {DataVoto:dd/MM/yyyy HH:mm}";
            else
                return base.ToString();
        }

        public static string ObterDescricao(TipoVotoEspecial tipo)
        {
            switch (tipo)
            {
                case TipoVotoEspecial.Branco:
                    return "Voto em Branco (não concorda com nenhum candidato)";
                case TipoVotoEspecial.Nulo:
                    return "Voto Nulo (protesto/erro)";
                default:
                    return "Voto Normal";
            }
        }
    }
}